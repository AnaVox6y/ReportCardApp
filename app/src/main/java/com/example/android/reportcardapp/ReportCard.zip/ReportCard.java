package com.example.android.reportcardapp;

/**
 * Created by Maino96-10022 on 10/19/2016.
 */

public class ReportCard {

    private static final int MAX_CLASS_SIZE = 30;
    private int mMathMark;
    private int mScienceMark;
    private int mEnglishMark;
    private int mHistoryMark;
    private int mPhysEdMark;


    public ReportCard(int MathMark, int ScienceMark, int EnglishMark,
                      int HistoryMark, int PhysEdMark) {

        mMathMark = MathMark;
        mScienceMark = ScienceMark;
        mEnglishMark = EnglishMark;
        mHistoryMark = HistoryMark;
        mPhysEdMark = PhysEdMark;


    }


    public void setmMathMark(int MathMark) {
        mMathMark = MathMark;
    }

    public int getmMathMark() {
        return mMathMark;
    }

    public void setmScienceMark(int ScienceMark) {
        mScienceMark = ScienceMark;
    }

    public int getmScienceMark() {
        return mScienceMark;

    }

    public void setmEnglishMark(int EnglishMark) {
        mEnglishMark = EnglishMark;
    }

    public int getmEnglishMark() {
        return mEnglishMark;

    }

    public void setmHistoryMark(int HistoryMark) {
        mHistoryMark = HistoryMark;
    }

    public int getmHistoryMark() {
        return mHistoryMark;

    }

    public void setmPhysEdMark(int PhysEdMark) {
        mPhysEdMark = PhysEdMark;
    }

    public int getmPhysEdMark() {
        return mPhysEdMark;

    }


    @Override
    public String toString() {
        return "Math: " + getmMathMark() + "\nScience " + getmScienceMark() +
                "\nEnglish: " + getmEnglishMark() + "\nHistory: " + getmHistoryMark() + "\nPhysEd: " + getmPhysEdMark();
    }

}
